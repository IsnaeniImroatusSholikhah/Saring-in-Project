package com.aplikasi.deteksihoax.utils

data class FeedbackModel(
    val message: String? = "",
    val rating: String? = "" ,
)