package com.aplikasi.deteksihoax.utils

data class IndicatorModel(
    val loading: Boolean?
)
